export declare function canIUseFormFieldButton(): boolean;
export declare function canUseVirtualHost(): boolean;
