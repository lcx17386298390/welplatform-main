import { TdColProps } from './type';
declare const props: TdColProps;
export default props;
