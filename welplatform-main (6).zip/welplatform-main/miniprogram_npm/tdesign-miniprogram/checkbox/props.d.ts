import { TdCheckboxProps } from './type';
declare const props: TdCheckboxProps;
export default props;
