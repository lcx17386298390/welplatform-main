export default {
    year: '',
    month: '',
    date: '',
    hour: '',
    minute: '',
    second: '',
    am: 'до полудня',
    pm: 'после полудня',
    confirm: 'подтвердить',
    cancel: 'отменить',
};
