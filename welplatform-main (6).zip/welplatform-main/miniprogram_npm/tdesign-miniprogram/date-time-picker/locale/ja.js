export default {
    year: '年',
    month: '月',
    date: '日',
    hour: '時',
    minute: '分',
    second: '秒',
    am: '午前',
    pm: '午後',
    confirm: '確認',
    cancel: 'キャンセル',
};
